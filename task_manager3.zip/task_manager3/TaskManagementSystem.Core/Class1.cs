﻿namespace TaskManagementSystem.Core;

public class Class1
{

}
