namespace TaskManagementSystem.Core.Enums
{
    public enum TaskState
    {
        Incomplete = 0,
        InProgress = 1,
        Completed = 2
    }
}